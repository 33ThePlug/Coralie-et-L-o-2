interface Window {
  originalFetch?: typeof fetch;
}